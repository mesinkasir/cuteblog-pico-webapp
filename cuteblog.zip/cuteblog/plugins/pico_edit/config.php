<?php

global $backend_password;

/*
 * This should be a sha256 hash of your password.
 * Use a tool like https://convertstring.com/Hash/SHA256 to generate.
 * pass: axcora
 */
$backend_password = 'E280A8E456D2FC7B9FE3189A916D1AA96FE19A1C09B73FBEE613A5A2E6A8AD7C';

?>