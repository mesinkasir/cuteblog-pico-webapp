---
Title: About Us
Description: About cuteblog for pico developer
Img: https://img.freepik.com/free-vector/people-putting-puzzle-pieces-together_52683-28610.jpg?w=2000
Template: post
---


Cuteblog is a [open source code project free download template themes](home/about) you can download and install it on your local device or cloud it on your shared hosting with easly..

Present by axcora technology for developer and user . work using [pico cms](https://picocms.org) make your site very powerfull and super fast !!

And if you need to build or develope modern website so you can contact our team for best solutions for you.

Unduh cute blog dan mulai bekerja dengan pico cms. tentunya kami juga membuka donasi agar tim pengembang kami dapat memberikan lagi kode sumber terbuka untuk kamu. silahkan donasi secara sukarela untuk sebuah kopi bagi para team developer kami.

Donasi ke :

+ BCA Bank 0181884109- Atas nama Suci Chanifah.


Dan jika kamu membutuhkan layanan pembuatan website modern maka kamu dapat menghubungi team developer kami untuk kebutuhan pembuatan website modern dengan markdown menggunakan pico cms ini.


Contact Us :
+ [Whatsapp →](https://wa.me/6285646104747)
+ [Call us →](tel:+62895339403223)
+ [Email →](mailto:axcora@gmail.com)

+ [Hire me →](https://www.fiverr.com/creativitas/create-your-website-with-cms)
+ [Buy me a coffee →](https://app.midtrans.com/payment-links/1647457988722)
